package com.example.pr06;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.snackbar.Snackbar;

import com.example.pr06.databinding.ActivityMainBinding;

import javax.crypto.SealedObject;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        TextWatcher watcher = new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
                boolean isFilled1 = !binding.inputHead.getText().toString().trim().isEmpty();
                boolean isFilled2 = !binding.inputLine.getText().toString().trim().isEmpty();
                binding.btCalculate.setEnabled(isFilled1);
                binding.btNext.setEnabled(isFilled1);
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
        };

        binding.inputLine.addTextChangedListener(watcher);
        binding.inputHead.addTextChangedListener(watcher);

        binding.btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                int length = binding.inputLine.length();
                if (length <= 0) {
                    Snackbar.make(binding.getRoot(), "Ошибка: введите текст", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra(SecondActivity.HEAD, binding.inputHead.getText().toString());
                intent.putExtra(SecondActivity.BODY, binding.inputLine.getText().toString());
                startActivity(intent);
            }
        });
        binding.btCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int length = binding.inputLine.length();
                if (length <= 0) {
                    Snackbar.make(binding.getRoot(), "Ошибка: введите текст", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                binding.resultText.setText(new StringBuilder().append(length).append("/200").toString());
            }
        });

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}